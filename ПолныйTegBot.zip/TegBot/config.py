API_TOKEN = '5626308217:AAEO-q8ppul8rXTqR23JonI1hXxXigkQrrM'

admin_id = '925830821'

dbHost = 'sql.freedb.tech'
dbUser = 'freedb_TegBog'
dbPassword = 'rr#y5c3!65SeVTK'
dbName = 'freedb_TegBot'
